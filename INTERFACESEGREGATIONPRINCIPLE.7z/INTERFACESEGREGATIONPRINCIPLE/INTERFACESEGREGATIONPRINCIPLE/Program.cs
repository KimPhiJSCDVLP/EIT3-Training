﻿using System;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    class Program
    {
        static void Main(string[] args)
        {
            IFish fish = new Fish();
            fish.Swim();
            Console.ReadKey();
        }
    }
    /// <summary>
    ///  Thay vì dùng 1 interface lớn, ta nên tách thành nhiều interface nhỏ, với nhiều mục đích cụ thể
    /// </summary>
}
