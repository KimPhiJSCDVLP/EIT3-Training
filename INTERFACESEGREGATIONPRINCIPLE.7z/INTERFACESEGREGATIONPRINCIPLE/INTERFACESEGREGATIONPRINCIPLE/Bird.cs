﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{

    public class Bird : IAnimal, IBird
    {
        public void Eat() { }
        public void Swim() { throw new Exception("Chim éo biết bơi"); }
        public void Fly() { }
        public void Drink()
        {
            throw new NotImplementedException();
        }

        public void Sleep()
        {
            throw new NotImplementedException();
        }
    }
}
