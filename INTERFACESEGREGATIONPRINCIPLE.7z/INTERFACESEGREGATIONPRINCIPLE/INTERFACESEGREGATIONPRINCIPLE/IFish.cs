﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    public interface IFish
    {
        void Swim();
    }
}
