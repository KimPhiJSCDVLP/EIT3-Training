﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    public class Fish : IAnimal, IFish
    {
        public void Eat() { }
        public void Swim() {
            Console.WriteLine("Cá bơi rất nhanh");
        }
        public void Fly() { throw new Exception("Cá éo biết bay"); }

        public void Drink()
        {
            throw new NotImplementedException();
        }

        public void Sleep()
        {
            throw new NotImplementedException();
        }
    }
}
