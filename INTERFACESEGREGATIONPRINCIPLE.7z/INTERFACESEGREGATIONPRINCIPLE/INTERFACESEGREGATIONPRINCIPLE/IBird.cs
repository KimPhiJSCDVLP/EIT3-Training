﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    public interface IBird
    {
        void Fly();
    }
}
