﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    public interface IAnimal
    {
        void Eat();
        void Drink();
        void Sleep();
    }
}
