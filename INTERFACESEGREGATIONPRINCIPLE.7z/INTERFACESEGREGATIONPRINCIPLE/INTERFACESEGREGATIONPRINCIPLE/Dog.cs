﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INTERFACESEGREGATIONPRINCIPLE
{
    public class Dog : IAnimal
    {
        public void Eat() { }
        public void Drink() { }
        public void Sleep() { }
    }
}

