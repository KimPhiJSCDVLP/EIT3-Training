﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    public class Student
    {
        public string StudentId { get; set; }
        public string StudentName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int Gender { get; set; } // 1 - Nam, 0 - Nu
        public Student() { }
        public Student(string studentId, string studentName, DateTime dateOfBirth, int gender) { 
            this.StudentId = studentId;
            this.StudentName = studentName;
            this.DateOfBirth = dateOfBirth;
            this.Gender = gender;
        }
    }
}
