﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class QuanLySinhVien : Form
    {
        StudentManagement studentManagement;
        public QuanLySinhVien()
        {
            InitializeComponent();
            studentManagement = new StudentManagement();
            LoadStudentData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // todo
        }

        void LoadStudentData()
        {
            var dataTable = new DataTable();
            CustomHeader(dataTable);
            dtgvstudent.Rows.Clear();
            AddRowsData(dataTable);
            dtgvstudent.DataSource = dataTable;
        }
        void CustomHeader(DataTable dataTable)
        {
            dataTable.Columns.Add("Mã Sinh Viên");
            dataTable.Columns.Add("Tên Sinh Viên");
            dataTable.Columns.Add("Ngày Sinh");
            dataTable.Columns.Add("Giới tính");
        }
        void AddRowsData(DataTable dataTable)
        {
            foreach (var item in studentManagement.Students)
            {
                var dateOfBirthFormat = item.DateOfBirth.ToString("dd-MM-yyyy");
                var genderName = item.Gender == 1? "Nam" : "Nữ";
                dataTable.Rows.Add(item.StudentId, item.StudentName, dateOfBirthFormat, genderName);
            }
        }
    }
}
