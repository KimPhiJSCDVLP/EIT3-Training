﻿using System;
using System.Linq;

namespace LiskovSubstitutionPrinciple
{


    class Program
    {
        static void Main(string[] args)
        {
            //var numbers = new int[] { 5, 7, 9, 2, 4, 6, 9 };
            //SumCalculator sum = new SumCalculator(numbers);
            //Console.WriteLine($"The sum of all the numbers: {sum.Calculate()}");

            //Console.WriteLine();

            //SumCalculator evenSum = new EvenNumbersSumCalculator(numbers);
            //Console.WriteLine($"The sum of all the even numbers: {evenSum.Calculate()}");

            //Console.ReadKey();
            var numbers = new int[] { 5, 7, 9, 2, 4, 6, 9 };
            Calculator sum = new SumCalculatorLSP(numbers);

            Console.WriteLine("The sum of all the numbers: {0}", sum.Calculate());
            Calculator evenSum = new EventNumbersSumCalculatorLSP(numbers);

            Console.WriteLine("The sum of all the even numbers: {0}", evenSum.Calculate());
            Console.ReadKey();
        }
    }
    /// <summary>
    /// Trong một chương trình, các object của class con có thể thay thế class cha mà không làm thay đổi tính đúng đắn của chương trình
    /// </summary>


    public class SumCalculator
    {
        protected readonly int[] _numbers;
        public SumCalculator(int[] numbers)
        {
            _numbers = numbers;
        }
        public int Calculate() {
            return _numbers.Sum();
        }
    }

    public class EvenNumbersSumCalculator : SumCalculator
    {
        public EvenNumbersSumCalculator(int[] numbers)
            : base(numbers)
        {
        }

        public new int Calculate() { 
            return _numbers.Where(x => x % 2 == 0).Sum();
        }
    }

    /// <summary>
    /// LSP
    /// </summary>
    /// 

    public abstract class Calculator
    {
        protected readonly int[] _numbers;
        public Calculator(int[] numbers)
        {
            _numbers = numbers;
        }

        public abstract int Calculate();
    }

    public class SumCalculatorLSP : Calculator
    {
        public SumCalculatorLSP(int[] numbers) : base(numbers)
        {
                
        }

        public override int Calculate()
        {
            return _numbers.Sum();
        }
    }


    public class EventNumbersSumCalculatorLSP : Calculator
    {
        public EventNumbersSumCalculatorLSP(int[] numbers) : base(numbers)
        {

        }

        public override int Calculate()
        {
            return _numbers.Where(x => x % 2 == 0).Sum();
        }
    }
}
