﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SingleResponsibilityPrinciple
{
    //Mỗi lớp chỉ nên chịu trách nhiệm về một nhiệm vụ cụ thể nào đó mà thôi.
    //Bad code
    public class Student
    {
        private string Name;
        private int Age;


        string GetStudentInfoHtml()
        {
            return "<span> Name: " + Name + ", age: " + Age + "</span>";
        }

        int ApplyForScholarship()
        {
            try
            {
                //Trying to apply for scholarship
            }
            catch
            {
                //write error to log file
                Console.WriteLine("Error_log.txt", "Error getting scholarship!");
            }
            return 0;
        }
    }

    public class Formatter
    {
        public string GetStudentInfoHtml(string name, int age)
        {
            return "<span> Name: " + name + ", age: " + age + "</span>";
        }
    }

    public class ExportLog
    {
        public void ExportLogToFile(string filename, string error)
        {
            //write error to log file
            Console.WriteLine(filename, error);
        }
    }

    ////Good code
    //public class Student
    //{
    //    private string Name;
    //    private int Age;


    //    string GetName()
    //    {
    //        return Name;
    //    }

    //    int GetAge()
    //    {
    //        return Age;
    //    }

    //    string GetStudentInfoHtml()
    //    {
    //        Formatter formatter = new Formatter();
    //        return formatter.GetStudentInfoHtml(Name, Age);
    //    }
    //    bool ApplyForScholarship()
    //    {
    //        try
    //        {
    //            // do something here
    //        }
    //        catch
    //        {
    //            ExportLog logControl = new ExportLog();
    //            logControl.ExportLogToFile("error_log.txt", "Error getting scholarship");
    //        }
    //        return true;
    //    }
    //}
}
