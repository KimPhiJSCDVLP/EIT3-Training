﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    public class Gender
    {
        public int Value { get; set; }
        public string Name { get; set; }
        public Gender(int value, string name) {
            this.Value = value;
            this.Name = name;
        }
    }
}
