﻿namespace QuanLySinhVien
{
    class SinhVien
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Sex { get; set; }
        public int Age { get; set; }
        public double DiemToan { get; set; }
        public double DiemLy { get; set; }
        public double DiemHoa { get; set; }
        public double DiemTB { get; set; }
        public string HocLuc { get; set; }
    }
}
