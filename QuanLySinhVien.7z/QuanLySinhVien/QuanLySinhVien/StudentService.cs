﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    public interface StudentService
    {
        Student GetById(string id);
        List<Student> GetStudents();
        Student Insert(Student student);
        Student Update(Student student);
        bool Delete(string id);
    }
}
