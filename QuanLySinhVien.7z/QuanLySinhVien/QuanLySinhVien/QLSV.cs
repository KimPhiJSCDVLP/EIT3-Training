﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class QuanLySinhVien : Form
    {
        StudentManagement studentManagement;
        public QuanLySinhVien()
        {
            InitializeComponent();
            studentManagement = new StudentManagement();
            LoadStudentData();
            LoadCombobox();
        }
        void LoadCombobox()
        {
            cbbGender.Items.Clear();

            var dataTable = new DataTable();
            dataTable.Columns.Add("Value", typeof(int));
            dataTable.Columns.Add("Name", typeof(string));

            var genders = new List<Gender>();
            genders.Add(new Gender(0, "Nữ"));
            genders.Add(new Gender(1, "Nam"));
            foreach (var item in genders)
            {
                dataTable.Rows.Add(item.Value, item.Name);
            }
            cbbGender.DataSource = dataTable;
            cbbGender.ValueMember = "Value";
            cbbGender.DisplayMember = "Name";
        }
        void LoadStudentData()
        {
            dtgvstudent.DataSource = null;
            var dataTable = new DataTable();
            CustomHeader(dataTable);
            AddRowsData(dataTable);
            dtgvstudent.DataSource = dataTable;
        }
        void CustomHeader(DataTable dataTable)
        {
            dataTable.Columns.Add("Mã Sinh Viên");
            dataTable.Columns.Add("Tên Sinh Viên");
            dataTable.Columns.Add("Ngày Sinh");
            dataTable.Columns.Add("Giới tính");
        }
        void AddRowsData(DataTable dataTable)
        {
            foreach (var item in studentManagement.Students)
            {
                var dateOfBirthFormat = item.DateOfBirth.ToString("dd-MM-yyyy");
                var genderName = item.Gender == 1 ? "Nam" : "Nữ";
                dataTable.Rows.Add(item.StudentId, item.StudentName, dateOfBirthFormat, genderName);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (DisplayDialogResult())
            {
                var student = new Student();
                student.StudentId = txbStudentId.Text;
                student.StudentName = txbStudentName.Text;
                student.DateOfBirth = dtpkDateOfBirth.Value;
                student.Gender = int.Parse(cbbGender.SelectedValue.ToString());
                var existStudent = studentManagement.GetById(student.StudentId);
                if (existStudent != null)
                {
                    var res = studentManagement.Update(student);
                    DisplayMessageBox(res != null);
                }
                else
                {
                    var res = studentManagement.Insert(student);
                    DisplayMessageBox(res != null);
                }
                LoadStudentData();
            }
        }
        void DisplayMessageBox(bool isSucess)
        {
            if (isSucess)
                MessageBox.Show("Success");
            else
                MessageBox.Show("Failed");
        }

        bool DisplayDialogResult()
        {
            DialogResult result = MessageBox.Show("Are you sure you want to proceed?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                return true;
            return false;
        }
    }
}
