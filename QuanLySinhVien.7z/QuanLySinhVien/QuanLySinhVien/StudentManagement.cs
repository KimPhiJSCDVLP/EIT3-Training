﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    public class StudentManagement : StudentService
    {
        public List<Student> Students { get; set; }
        public StudentManagement() { 
            Students = new List<Student>();
            SeedStudentData();
        }
        public bool Delete(string id)
        {
            var existStudent = Students.FirstOrDefault(x => x.StudentId == id);
            if (existStudent != null)
            {
                Students.Remove(existStudent);
                return true;
            }
            return false;
        }

        public Student GetById(string id)
        {
            return Students.FirstOrDefault(x => x.StudentId == id);
        }

        public List<Student> GetStudents()
        {
            return Students;
        }

        public Student Insert(Student student)
        {
            try
            {
                Students.Add(student);
                return student;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public Student Update(Student student)
        {
            var existStudent = Students.FirstOrDefault(x => x.StudentId == student.StudentId);
            if (existStudent != null)
            {
                existStudent.StudentId = student.StudentId;
                existStudent.StudentName = student.StudentName;
                existStudent.Gender = student.Gender;
                existStudent.DateOfBirth = student.DateOfBirth;
                return existStudent;
            }
            return null;
        }

        void SeedStudentData()
        {
            Students.Add(new Student("SV01", "Nguyen Van A", new DateTime(1998, 10, 25), 1));
            Students.Add(new Student("SV02", "Nguyen Thi B", new DateTime(1998, 5, 25), 0));
            Students.Add(new Student("SV03", "Nguyen Van C", new DateTime(1997, 9, 20), 1));
        }
    }
}
