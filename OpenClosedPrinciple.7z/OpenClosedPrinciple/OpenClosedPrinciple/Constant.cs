﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClosedPrinciple
{
    public class Constant
    {
        public const double STANDARD_FEE = 1000;
    }
}
