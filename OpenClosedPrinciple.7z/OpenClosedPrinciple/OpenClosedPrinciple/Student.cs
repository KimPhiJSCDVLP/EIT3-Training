﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClosedPrinciple
{
    //Chúng ta nên hạn chế việc chỉnh sửa bên trong một Class hoặc Module có sẵn, thay vào đó hãy xem xét mở rộng chúng.
    //Bad code
    //public class Student
    //{
    //    private string Name;
    //    private int Age;
    //    private string StudentType;
    //    public double PayTuitionFee()
    //    {
    //        if (StudentType == "foreign")
    //            return Constant.STANDARD_FEE * 1.3;
    //        else if (StudentType == "talented")
    //            return Constant.STANDARD_FEE * 0.8;
    //        else
    //            return Constant.STANDARD_FEE;
    //    }
    //}

    //Good code
    public class Student
    {
        private string Name;
        private int Age;
        public virtual double PayTuitionFee()
        {
            return Constant.STANDARD_FEE;
        }
    }

    public class AdvancedStudent : Student
    {
        public override double PayTuitionFee()
        {
            return Constant.STANDARD_FEE * 0.8;
        }

    }

    //public class ForeignStudent : Student
    //{
    //    public override double PayTuitionFee()
    //    {
    //        return Constant.STANDARD_FEE * 1.3;
    //    }
    //}


    //Can expand further
    public class ForeignStudent : Student
    {
        private int IELTSMark;
        private string Visa;

        public override double PayTuitionFee()
        {
            return Constant.STANDARD_FEE * 1.3;
        }

        bool IsQualifyForEnglish()
        {
            return IELTSMark > 8.0;
        }

        string ShowVisa()
        {
            return Visa;
        }

    }
}
