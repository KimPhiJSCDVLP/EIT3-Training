﻿using Lesson6WinForm.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lesson6WinForm
{
    public partial class ClassManagement : Form
    {
        List<Class> classes;
        public ClassManagement()
        {
            classes = new List<Class>();
            MockData();
            InitializeComponent();
            LoadDataClass();
        }

        private void btnQlsv_Click(object sender, EventArgs e)
        {
            this.Hide();
            var studentManagement = new StudentManagement();
            studentManagement.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var cl = new Class();
            cl.Id = txbClassId.Text;
            cl.Name = txbClassName.Text;
            classes.Add(cl);
            LoadDataClass();
        }
        private void LoadDataClass()
        {
            dtgvClasses.DataSource = null;
            DataTable table = new DataTable();
            table.Columns.Add("Mã lớp");
            table.Columns.Add("Tên Lớp");
            table.Columns.Add("Tên Lớp DP");
            foreach (var item in classes)
            {
                table.Rows.Add(item.Id, item.Name, !String.IsNullOrEmpty(item.DisplayName) ? item.DisplayName : "ABC");
            }
            dtgvClasses.DataSource = table;
        }
        private void MockData()
        {
            var cl = new Class();
            cl.Id = "Lop 1 ";
            cl.Name = "L1";
            classes.Add(cl);
            var cl2 = new Class();
            cl2.Id = "Lop 2";
            cl2.Name = "L2";
            classes.Add(cl2);
            var cl3 = new Class();
            cl3.Id = "Lop 3";
            cl3.Name = "L3";
            classes.Add(cl3);
            var cl4 = new Class();
            cl4.Id = "Lop 4";
            cl4.Name = "L4";
            classes.Add(cl4);
        }

        private void pgBPercent_Click(object sender, EventArgs e)
        {
            pgBPercent.Enabled = true;
            pgBPercent.Value = 50;
        }
    }
}
