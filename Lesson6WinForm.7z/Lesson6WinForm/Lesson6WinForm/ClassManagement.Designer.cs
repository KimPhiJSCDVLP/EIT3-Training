﻿namespace Lesson6WinForm
{
    partial class ClassManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.lbClassName = new System.Windows.Forms.Label();
            this.txbClassName = new System.Windows.Forms.TextBox();
            this.lbClassId = new System.Windows.Forms.Label();
            this.txbClassId = new System.Windows.Forms.TextBox();
            this.dtgvClasses = new System.Windows.Forms.DataGridView();
            this.btnQlsv = new System.Windows.Forms.Button();
            this.pgBPercent = new System.Windows.Forms.ProgressBar();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClasses)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(562, 59);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lbClassName
            // 
            this.lbClassName.AutoSize = true;
            this.lbClassName.Location = new System.Drawing.Point(25, 62);
            this.lbClassName.Name = "lbClassName";
            this.lbClassName.Size = new System.Drawing.Size(50, 13);
            this.lbClassName.TabIndex = 1;
            this.lbClassName.Text = "Tên Lớp:";
            // 
            // txbClassName
            // 
            this.txbClassName.Location = new System.Drawing.Point(81, 59);
            this.txbClassName.Name = "txbClassName";
            this.txbClassName.Size = new System.Drawing.Size(138, 20);
            this.txbClassName.TabIndex = 2;
            // 
            // lbClassId
            // 
            this.lbClassId.AutoSize = true;
            this.lbClassId.Location = new System.Drawing.Point(248, 62);
            this.lbClassId.Name = "lbClassId";
            this.lbClassId.Size = new System.Drawing.Size(42, 13);
            this.lbClassId.TabIndex = 1;
            this.lbClassId.Text = "Mã lớp:";
            // 
            // txbClassId
            // 
            this.txbClassId.Location = new System.Drawing.Point(304, 59);
            this.txbClassId.Name = "txbClassId";
            this.txbClassId.Size = new System.Drawing.Size(191, 20);
            this.txbClassId.TabIndex = 2;
            // 
            // dtgvClasses
            // 
            this.dtgvClasses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvClasses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvClasses.Location = new System.Drawing.Point(28, 125);
            this.dtgvClasses.Name = "dtgvClasses";
            this.dtgvClasses.Size = new System.Drawing.Size(609, 263);
            this.dtgvClasses.TabIndex = 3;
            // 
            // btnQlsv
            // 
            this.btnQlsv.Location = new System.Drawing.Point(685, 244);
            this.btnQlsv.Name = "btnQlsv";
            this.btnQlsv.Size = new System.Drawing.Size(75, 23);
            this.btnQlsv.TabIndex = 0;
            this.btnQlsv.Text = "QLSV";
            this.btnQlsv.UseVisualStyleBackColor = true;
            this.btnQlsv.Click += new System.EventHandler(this.btnQlsv_Click);
            // 
            // pgBPercent
            // 
            this.pgBPercent.Location = new System.Drawing.Point(81, 96);
            this.pgBPercent.Name = "pgBPercent";
            this.pgBPercent.Size = new System.Drawing.Size(209, 23);
            this.pgBPercent.TabIndex = 4;
            this.pgBPercent.Click += new System.EventHandler(this.pgBPercent_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(591, 88);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Visible = false;
            // 
            // ClassManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.pgBPercent);
            this.Controls.Add(this.dtgvClasses);
            this.Controls.Add(this.txbClassId);
            this.Controls.Add(this.lbClassId);
            this.Controls.Add(this.txbClassName);
            this.Controls.Add(this.lbClassName);
            this.Controls.Add(this.btnQlsv);
            this.Controls.Add(this.btnAdd);
            this.Name = "ClassManagement";
            this.Text = "QuanLyLopHoc";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvClasses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lbClassName;
        private System.Windows.Forms.TextBox txbClassName;
        private System.Windows.Forms.Label lbClassId;
        private System.Windows.Forms.TextBox txbClassId;
        private System.Windows.Forms.DataGridView dtgvClasses;
        private System.Windows.Forms.Button btnQlsv;
        private System.Windows.Forms.ProgressBar pgBPercent;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}

