﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Phanso a = Gan(1, 2), b = Gan(3, 4);
            //Hien(a);
            //Hien(b);
            //Phanso c = Cong(a, b);
            //Hien(Toigian(c));
            //Phanso[] phansos = {
            //    Gan(1,2),Gan(2,3),Gan(3,4),Gan(4,5)
            //};
            //Phanso tong = Gan(0, 1);
            //for (int i = 0; i < phansos.Length; i++)
            //{
            //    Hien(phansos[i]);
            //    Console.WriteLine();
            //    tong = Cong(tong, phansos[i]);
            //}
            //Hien(Toigian(tong));
            //Console.ReadKey();
        }
        static Phanso Gan(int t, int m)
        {
            Phanso p;
            p.Tu = t;
            p.Mau = m;
            return p;
        }
        struct Phanso
        {
            public int Tu;
            public int Mau;
        };
        static void Hien(Phanso p)
        {
            Console.WriteLine("{0}/{1}\n", p.Tu, p.Mau);
        }
        static Phanso Cong(Phanso p1, Phanso p2)
        {
            return Gan(p1.Tu * p2.Mau + p1.Mau * p2.Tu, p1.Mau * p2.Mau);
        }
        static Phanso Toigian(Phanso p)
        {
            int t = p.Tu, m = p.Mau;
            while (t != m)
            {
                if (t > m) t = t - m;
                if (m > t) m = m - t;
            }
            return Gan(p.Tu / t, p.Mau / m);
        }
    }
}
